CREATE VIEW v_user AS
  SELECT
    `electronics_store`.`user`.`id`                   AS `id`,
    `electronics_store`.`role`.`id`                   AS `role_id`,
    `electronics_store`.`role`.`name`                 AS `role_name`,
    `electronics_store`.`user`.`avatar`               AS `avatar`,
    `electronics_store`.`user`.`login`                AS `login`,
    `electronics_store`.`user`.`password`             AS `password`,
    `electronics_store`.`user`.`date_of_registration` AS `date_of_registration`
  FROM (`electronics_store`.`user`
    JOIN `electronics_store`.`role` ON (`electronics_store`.`role`.`id` = `electronics_store`.`user`.`role_id`));
