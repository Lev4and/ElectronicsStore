CREATE VIEW v_city AS
  SELECT
    `electronics_store`.`city`.`id`      AS `id`,
    `electronics_store`.`region`.`id`    AS `region_id`,
    `electronics_store`.`region`.`name`  AS `region_name`,
    `electronics_store`.`country`.`id`   AS `country_id`,
    `electronics_store`.`country`.`name` AS `country_name`,
    `electronics_store`.`city`.`name`    AS `name`
  FROM ((`electronics_store`.`city`
    JOIN `electronics_store`.`region`
      ON (`electronics_store`.`region`.`id` = `electronics_store`.`city`.`region_id`)) JOIN
    `electronics_store`.`country` ON (`electronics_store`.`country`.`id` = `electronics_store`.`region`.`country_id`));
