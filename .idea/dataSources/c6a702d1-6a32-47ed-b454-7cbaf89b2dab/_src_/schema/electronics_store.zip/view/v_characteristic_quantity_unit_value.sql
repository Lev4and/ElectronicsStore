CREATE VIEW v_characteristic_quantity_unit_value AS
  SELECT
    `electronics_store`.`characteristic_quantity_unit_value`.`id`    AS `id`,
    `electronics_store`.`characteristic`.`id`                        AS `characteristic_id`,
    `electronics_store`.`characteristic`.`name`                      AS `characteristic_name`,
    `electronics_store`.`quantity_unit`.`id`                         AS `quantity_unit_id`,
    `electronics_store`.`quantity`.`id`                              AS `quantity_id`,
    `electronics_store`.`quantity`.`name`                            AS `quantity_name`,
    `electronics_store`.`unit`.`id`                                  AS `unit_id`,
    `electronics_store`.`unit`.`name`                                AS `unit_name`,
    `electronics_store`.`unit`.`designation`                         AS `unit_designation`,
    `electronics_store`.`characteristic_quantity_unit_value`.`value` AS `value`
  FROM ((((`electronics_store`.`characteristic_quantity_unit_value`
    JOIN `electronics_store`.`characteristic` ON (`electronics_store`.`characteristic`.`id` =
                                                  `electronics_store`.`characteristic_quantity_unit_value`.`characteristic_id`)) JOIN
    `electronics_store`.`quantity_unit` ON (`electronics_store`.`quantity_unit`.`id` =
                                            `electronics_store`.`characteristic_quantity_unit_value`.`quantity_unit_id`)) JOIN
    `electronics_store`.`quantity`
      ON (`electronics_store`.`quantity`.`id` = `electronics_store`.`quantity_unit`.`quantity_id`)) JOIN
    `electronics_store`.`unit` ON (`electronics_store`.`unit`.`id` = `electronics_store`.`quantity_unit`.`unit_id`));
