CREATE VIEW v_product AS
  SELECT
    `electronics_store`.`product`.`id`                                                     AS `id`,
    `electronics_store`.`category_subcategory`.`id`                                        AS `category_subcategory_id`,
    `electronics_store`.`category_subcategory`.`name`                                      AS `category_subcategory_name`,
    `electronics_store`.`subcategory`.`id`                                                 AS `subcategory_id`,
    `electronics_store`.`subcategory`.`name`                                               AS `subcategory_name`,
    `electronics_store`.`category`.`id`                                                    AS `category_id`,
    `electronics_store`.`category`.`name`                                                  AS `category_name`,
    `electronics_store`.`classification`.`id`                                              AS `classification_id`,
    `electronics_store`.`classification`.`name`                                            AS `classification_name`,
    `electronics_store`.`manufacturer`.`id`                                                AS `manufacturer_id`,
    `electronics_store`.`manufacturer`.`name`                                              AS `manufacturer_name`,
    `electronics_store`.`product`.`photo`                                                  AS `photo`,
    `electronics_store`.`product`.`model`                                                  AS `model`,
    concat(`electronics_store`.`category_subcategory`.`name`, ' ', `electronics_store`.`manufacturer`.`name`, ' ',
           `electronics_store`.`product`.`model`)                                          AS `name`,
    (SELECT avg(cast(`electronics_store`.`review`.`evaluation` AS FLOAT))
     FROM `electronics_store`.`review`
     WHERE `electronics_store`.`review`.`product_id` = `electronics_store`.`product`.`id`) AS `evaluation`,
    (SELECT count(0)
     FROM `electronics_store`.`review`
     WHERE `electronics_store`.`review`.`product_id` = `electronics_store`.`product`.`id`) AS `count_of_evaluations`,
    `electronics_store`.`product`.`description`                                            AS `description`,
    `electronics_store`.`product`.`price`                                                  AS `price`
  FROM (((((`electronics_store`.`product`
    JOIN `electronics_store`.`category_subcategory` ON (`electronics_store`.`category_subcategory`.`id` =
                                                        `electronics_store`.`product`.`category_subcategory_id`)) JOIN
    `electronics_store`.`subcategory`
      ON (`electronics_store`.`subcategory`.`id` = `electronics_store`.`category_subcategory`.`subcategory_id`)) JOIN
    `electronics_store`.`category`
      ON (`electronics_store`.`category`.`id` = `electronics_store`.`subcategory`.`category_id`)) JOIN
    `electronics_store`.`classification`
      ON (`electronics_store`.`classification`.`id` = `electronics_store`.`category`.`classification_id`)) JOIN
    `electronics_store`.`manufacturer`
      ON (`electronics_store`.`manufacturer`.`id` = `electronics_store`.`product`.`manufacturer_id`));
