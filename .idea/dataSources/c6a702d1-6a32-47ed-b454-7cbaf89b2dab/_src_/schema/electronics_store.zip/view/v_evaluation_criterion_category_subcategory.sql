CREATE VIEW v_evaluation_criterion_category_subcategory AS
  SELECT
    `electronics_store`.`evaluation_criterion_category_subcategory`.`id` AS `id`,
    `electronics_store`.`evaluation_criterion`.`id`                      AS `evaluation_criterion_id`,
    `electronics_store`.`evaluation_criterion`.`name`                    AS `evaluation_criterion_name`,
    `electronics_store`.`category_subcategory`.`id`                      AS `category_subcategory_id`,
    `electronics_store`.`category_subcategory`.`name`                    AS `category_subcategory_name`,
    `electronics_store`.`subcategory`.`id`                               AS `subcategory_id`,
    `electronics_store`.`subcategory`.`name`                             AS `subcategory_name`,
    `electronics_store`.`category`.`id`                                  AS `category_id`,
    `electronics_store`.`category`.`name`                                AS `category_name`,
    `electronics_store`.`classification`.`id`                            AS `classification_id`,
    `electronics_store`.`classification`.`name`                          AS `classification_name`
  FROM (((((`electronics_store`.`evaluation_criterion_category_subcategory`
    JOIN `electronics_store`.`evaluation_criterion` ON (`electronics_store`.`evaluation_criterion`.`id` =
                                                        `electronics_store`.`evaluation_criterion_category_subcategory`.`evaluation_criterion_id`)) JOIN
    `electronics_store`.`category_subcategory` ON (`electronics_store`.`category_subcategory`.`id` =
                                                   `electronics_store`.`evaluation_criterion_category_subcategory`.`category_subcategory_id`)) JOIN
    `electronics_store`.`subcategory`
      ON (`electronics_store`.`subcategory`.`id` = `electronics_store`.`category_subcategory`.`subcategory_id`)) JOIN
    `electronics_store`.`category`
      ON (`electronics_store`.`category`.`id` = `electronics_store`.`subcategory`.`category_id`)) JOIN
    `electronics_store`.`classification`
      ON (`electronics_store`.`classification`.`id` = `electronics_store`.`category`.`classification_id`));
