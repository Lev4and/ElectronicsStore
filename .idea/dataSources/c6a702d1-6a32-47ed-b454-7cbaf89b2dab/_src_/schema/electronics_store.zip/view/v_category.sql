CREATE VIEW v_category AS
  SELECT
    `electronics_store`.`category`.`id`         AS `id`,
    `electronics_store`.`classification`.`id`   AS `classification_id`,
    `electronics_store`.`classification`.`name` AS `classification_name`,
    `electronics_store`.`category`.`name`       AS `name`,
    `electronics_store`.`category`.`photo`      AS `photo`
  FROM (`electronics_store`.`category`
    JOIN `electronics_store`.`classification`
      ON (`electronics_store`.`classification`.`id` = `electronics_store`.`category`.`classification_id`));
