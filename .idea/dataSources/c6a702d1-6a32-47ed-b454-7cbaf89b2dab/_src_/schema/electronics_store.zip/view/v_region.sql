CREATE VIEW v_region AS
  SELECT
    `electronics_store`.`region`.`id`    AS `id`,
    `electronics_store`.`country`.`id`   AS `country_id`,
    `electronics_store`.`country`.`name` AS `country_name`,
    `electronics_store`.`region`.`name`  AS `name`
  FROM (`electronics_store`.`region`
    JOIN `electronics_store`.`country`
      ON (`electronics_store`.`country`.`id` = `electronics_store`.`region`.`country_id`));
