CREATE VIEW v_category_subcategory AS
  SELECT
    `electronics_store`.`category_subcategory`.`id`    AS `id`,
    `electronics_store`.`category_subcategory`.`photo` AS `photo`,
    `electronics_store`.`subcategory`.`id`             AS `subcategory_id`,
    `electronics_store`.`subcategory`.`name`           AS `subcategory_name`,
    `electronics_store`.`category`.`id`                AS `category_id`,
    `electronics_store`.`category`.`name`              AS `category_name`,
    `electronics_store`.`classification`.`id`          AS `classification_id`,
    `electronics_store`.`classification`.`name`        AS `classification_name`,
    `electronics_store`.`category_subcategory`.`name`  AS `name`
  FROM (((`electronics_store`.`category_subcategory`
    JOIN `electronics_store`.`subcategory`
      ON (`electronics_store`.`subcategory`.`id` = `electronics_store`.`category_subcategory`.`subcategory_id`)) JOIN
    `electronics_store`.`category`
      ON (`electronics_store`.`category`.`id` = `electronics_store`.`subcategory`.`category_id`)) JOIN
    `electronics_store`.`classification`
      ON (`electronics_store`.`classification`.`id` = `electronics_store`.`category`.`classification_id`));
