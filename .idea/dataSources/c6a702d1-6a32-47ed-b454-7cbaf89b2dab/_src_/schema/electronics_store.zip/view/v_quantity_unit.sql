CREATE VIEW v_quantity_unit AS
  SELECT
    `electronics_store`.`quantity_unit`.`id` AS `id`,
    `electronics_store`.`quantity`.`id`      AS `quantity_id`,
    `electronics_store`.`quantity`.`name`    AS `quantity_name`,
    `electronics_store`.`unit`.`id`          AS `unit_id`,
    `electronics_store`.`unit`.`name`        AS `unit_name`,
    `electronics_store`.`unit`.`designation` AS `unit_designation`
  FROM ((`electronics_store`.`quantity_unit`
    JOIN `electronics_store`.`quantity`
      ON (`electronics_store`.`quantity`.`id` = `electronics_store`.`quantity_unit`.`quantity_id`)) JOIN
    `electronics_store`.`unit` ON (`electronics_store`.`unit`.`id` = `electronics_store`.`quantity_unit`.`unit_id`));
