CREATE VIEW v_product_characteristic_quantity_unit_value AS
  SELECT
    `electronics_store`.`product_characteristic_quantity_unit_value`.`product_id`                        AS `product_id`,
    `v_characteristic_quantity_unit_value`.`id`                                                          AS `characteristic_quantity_unit_value_id`,
    `v_characteristic_quantity_unit_value`.`characteristic_id`                                           AS `characteristic_id`,
    `v_characteristic_quantity_unit_value`.`characteristic_name`                                         AS `characteristic_name`,
    `v_characteristic_quantity_unit_value`.`quantity_unit_id`                                            AS `quantity_unit_id`,
    `v_characteristic_quantity_unit_value`.`quantity_id`                                                 AS `quantity_id`,
    `v_characteristic_quantity_unit_value`.`quantity_name`                                               AS `quantity_name`,
    `v_characteristic_quantity_unit_value`.`unit_id`                                                     AS `unit_id`,
    `v_characteristic_quantity_unit_value`.`unit_name`                                                   AS `unit_name`,
    `v_characteristic_quantity_unit_value`.`unit_designation`                                            AS `unit_designation`,
    `v_characteristic_quantity_unit_value`.`value`                                                       AS `value`,
    `electronics_store`.`section_category_subcategory`.`id`                                              AS `section_category_subcategory_id`,
    `electronics_store`.`section`.`id`                                                                   AS `section_id`,
    `electronics_store`.`section`.`name`                                                                 AS `section_name`,
    `electronics_store`.`characteristic_category_subcategory`.`use_when_displaying_as_basic_information` AS `use_when_displaying_as_basic_information`
  FROM (((((`electronics_store`.`product_characteristic_quantity_unit_value`
    JOIN `electronics_store`.`v_characteristic_quantity_unit_value` ON (`v_characteristic_quantity_unit_value`.`id` =
                                                                        `electronics_store`.`product_characteristic_quantity_unit_value`.`characteristic_quantity_unit_value_id`)) JOIN
    `electronics_store`.`product` ON (`electronics_store`.`product`.`id` =
                                      `electronics_store`.`product_characteristic_quantity_unit_value`.`product_id`)) JOIN
    `electronics_store`.`characteristic_category_subcategory` ON (
      `electronics_store`.`characteristic_category_subcategory`.`characteristic_id` =
      `v_characteristic_quantity_unit_value`.`characteristic_id` AND
      `electronics_store`.`characteristic_category_subcategory`.`category_subcategory_id` =
      `electronics_store`.`product`.`category_subcategory_id`)) JOIN `electronics_store`.`section_category_subcategory`
      ON (`electronics_store`.`section_category_subcategory`.`id` =
          `electronics_store`.`characteristic_category_subcategory`.`section_category_subcategory_id`)) JOIN
    `electronics_store`.`section`
      ON (`electronics_store`.`section`.`id` = `electronics_store`.`section_category_subcategory`.`section_id`));
