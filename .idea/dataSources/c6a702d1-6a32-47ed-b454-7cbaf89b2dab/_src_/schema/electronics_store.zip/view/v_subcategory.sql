CREATE VIEW v_subcategory AS
  SELECT
    `electronics_store`.`subcategory`.`id`      AS `id`,
    `electronics_store`.`subcategory`.`photo`   AS `photo`,
    `electronics_store`.`category`.`id`         AS `category_id`,
    `electronics_store`.`category`.`name`       AS `category_name`,
    `electronics_store`.`classification`.`id`   AS `classification_id`,
    `electronics_store`.`classification`.`name` AS `classification_name`,
    `electronics_store`.`subcategory`.`name`    AS `name`
  FROM ((`electronics_store`.`subcategory`
    JOIN `electronics_store`.`category`
      ON (`electronics_store`.`category`.`id` = `electronics_store`.`subcategory`.`category_id`)) JOIN
    `electronics_store`.`classification`
      ON (`electronics_store`.`classification`.`id` = `electronics_store`.`category`.`classification_id`));
