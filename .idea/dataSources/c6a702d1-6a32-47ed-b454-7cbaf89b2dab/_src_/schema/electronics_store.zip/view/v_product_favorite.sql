CREATE VIEW v_product_favorite AS
  SELECT
    `electronics_store`.`product_favorite`.`id`             AS `id`,
    `v_product`.`id`                                        AS `product_id`,
    `v_product`.`category_subcategory_id`                   AS `category_subcategory_id`,
    `v_product`.`category_subcategory_name`                 AS `category_subcategory_name`,
    `v_product`.`subcategory_id`                            AS `subcategory_id`,
    `v_product`.`subcategory_name`                          AS `subcategory_name`,
    `v_product`.`category_id`                               AS `category_id`,
    `v_product`.`category_name`                             AS `category_name`,
    `v_product`.`classification_id`                         AS `classification_id`,
    `v_product`.`classification_name`                       AS `classification_name`,
    `v_product`.`manufacturer_id`                           AS `manufacturer_id`,
    `v_product`.`manufacturer_name`                         AS `manufacturer_name`,
    `v_product`.`photo`                                     AS `photo`,
    `v_product`.`model`                                     AS `model`,
    `v_product`.`name`                                      AS `name`,
    `v_product`.`evaluation`                                AS `evaluation`,
    `v_product`.`count_of_evaluations`                      AS `count_of_evaluations`,
    `v_product`.`description`                               AS `description`,
    `v_product`.`price`                                     AS `price`,
    `v_user`.`id`                                           AS `user_id`,
    `v_user`.`role_id`                                      AS `role_id`,
    `v_user`.`role_name`                                    AS `role_name`,
    `v_user`.`avatar`                                       AS `avatar`,
    `v_user`.`login`                                        AS `login`,
    `v_user`.`password`                                     AS `password`,
    `v_user`.`date_of_registration`                         AS `date_of_registration`,
    `electronics_store`.`product_favorite`.`date_of_adding` AS `date_of_adding`
  FROM ((`electronics_store`.`product_favorite`
    JOIN `electronics_store`.`v_product`
      ON (`v_product`.`id` = `electronics_store`.`product_favorite`.`product_id`)) JOIN `electronics_store`.`v_user`
      ON (`v_user`.`id` = `electronics_store`.`product_favorite`.`user_id`));
