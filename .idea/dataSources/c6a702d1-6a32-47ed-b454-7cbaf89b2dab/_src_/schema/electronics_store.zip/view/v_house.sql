CREATE VIEW v_house AS
  SELECT
    `electronics_store`.`house`.`id`     AS `id`,
    `electronics_store`.`street`.`id`    AS `street_id`,
    `electronics_store`.`street`.`name`  AS `street_name`,
    `electronics_store`.`city`.`id`      AS `city_id`,
    `electronics_store`.`city`.`name`    AS `city_name`,
    `electronics_store`.`region`.`id`    AS `region_id`,
    `electronics_store`.`region`.`name`  AS `region_name`,
    `electronics_store`.`country`.`id`   AS `country_id`,
    `electronics_store`.`country`.`name` AS `country_name`,
    `electronics_store`.`house`.`name`   AS `name`
  FROM ((((`electronics_store`.`house`
    JOIN `electronics_store`.`street`
      ON (`electronics_store`.`street`.`id` = `electronics_store`.`house`.`street_id`)) JOIN `electronics_store`.`city`
      ON (`electronics_store`.`city`.`id` = `electronics_store`.`street`.`city_id`)) JOIN `electronics_store`.`region`
      ON (`electronics_store`.`region`.`id` = `electronics_store`.`city`.`region_id`)) JOIN
    `electronics_store`.`country` ON (`electronics_store`.`country`.`id` = `electronics_store`.`region`.`country_id`));
